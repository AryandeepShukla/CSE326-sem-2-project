var index_maker = 0;
//This variable is used to determin the status of the button
function resize() {
  if (index_maker == 0) {
    document.getElementsByClassName('container')[0].style.height = '70vh';
    document.getElementsByClassName('container')[1].style.height = '70vh';
    document.getElementById('otherPrograms').style.bottom = '20vh';
    document.getElementById('bt1').innerText = 'Read Less';
    document.getElementById('bt2').innerText = 'Read Less';
    index_maker = 1;
  } else {
    document.getElementsByClassName('container')[0].style.height = '60vh';
    document.getElementsByClassName('container')[1].style.height = '60vh';
    document.getElementById('otherPrograms').style.bottom = '10vh';
    document.getElementById('bt1').innerText = 'Read More';
    document.getElementById('bt2').innerText = 'Read More';
    index_maker = 0;
  }
}
